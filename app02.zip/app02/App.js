import * as React from 'react';
import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';

export default function App(){
  return(
    <View style={estilo.container}>

      <Text style={estilo.titulo}> Historia </Text>
      <Text style={estilo.frase}></Text>
      <ScrollView style={estilo.fotos}>
        <Image style={estilo.img} source={require("./assets/OIP.jpg")}/>
      <Text style={estilo.legenda}> Minhas Férias...</Text>
        <Image style={estilo.img} source={require("./assets/wp5095134.jpg")}/>
</ScrollView>
    </View>

  );


}

const estilo = StyleSheet.create({
container:{
flex:1,
alignItems:'center', 
backgroundColor: '#00fa9a'

},  
titulo:{
textAlign:'center',
fontSize:40,
marginTop:50,
},
frase:{
fontSize: 15,
marginBottom: 20,
textAlign:'right',
fontSize:20,

},
img:{
width:360,
height:500,
},
legenda:{
  textAlign:'center',
  marginTop: 20,
  marginBottom: 20,
  fontSize:20,
  fontFamily: 'Verdena',
  },
fotos:{
  alignItems: 'center'
}

});